Config = {
    position = vector3(-219.45, -1162.38, 23.02),
    drawDist = 25.0,
    
    -- DO NOT CHANGE THIS
    identifier = 1,
}
